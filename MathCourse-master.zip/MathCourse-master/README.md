# MathCourse
This repo stores file that refers to `MATH`. LOL.

* Note: GalvinGao/Geometry is no longer a valid repository in GitHub. Instead of `Geometry`, we `MATH`!!1
